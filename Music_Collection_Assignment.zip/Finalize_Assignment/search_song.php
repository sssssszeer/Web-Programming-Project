<?php
	session_start();
	$_SESSION['song_name'] = $_POST['search_song'];
	header('Location: search_song_result.php');
	if(isset ($_SESSION["UID"])){
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Fortress's Music Collection</title>
<link rel="stylesheet" type="text/css" href="admin.css">
<style>

       body {
            background-image: url('bg4.jpg');
            background-repeat: no-repeat;
            background-size: cover;
			background-attachment: fixed;
            margin: 0; 
            display: flex;
            justify-content: center; 
            align-items: center; 
        }
		
		.kotak {
			padding: 8px 15px;
			cursor: pointer;
			width: 200px;
		}	
		input{
			display: block;
			height: 50px;
			width: 100%;
			background-color: rgba(255,255,255,0.3);
			border-radius: 100px;
			padding: 0 10px;
			margin-top: 8px;
			font-size: 14px;
			font-weight: 300;
		}

        table {
            width: 100%;
            max-width: 800px; 
            background-color: rgba(0, 0, 0, 1);
            border-radius: 5px;
            border: 5px solid rgba(0, 0, 0, 0.6);
            box-shadow: 0 0 60px rgba(65, 65, 65, 1);
            
        }
		
		table td {
			padding: 30px;
			font-size: 18px;
			background-color:#A9A9A9;
		}
		
		table th {
			padding: 15px;
			font-size: 18px;
			background-color:#444444;
			color:white;
		}
		
		table td:nth-child(6) {
			white-space: nowrap;
		}
.back-button {
	background-color: rgba(255,255,255,0.13);
	border: 5px solid rgba(0,0,0,0.5);
	box-shadow: 0 0 60px rgba(255,255,255,0.6);
	cursor: pointer;
	width: auto;
	height: auto;
	position: fixed;
	top:10px;
	left:10px;
}
		
</style>
</head>

<?php
		$song_name = $_POST["search_song"];
		$host = "localhost";
		$user = "root";
		$pass = "";
		$db = "dc98701music_library";
		
		$conn = new mysqli ($host, $user, $pass, $db);
		
		if ($conn -> connect_error) {
			die ("Connection Faileeeed ". $conn -> connect_error);
		}
		else {


		}
	?>

</body>
</html>
<?php
} else {
?>
<!DOCTYPE html>
<html>
<head>
<title>Fortress's Music Collection</title>
<link rel="stylesheet" type="text/css" href="user.css">

<style>
body{
    background-image: url('bg.gif');
    height: auto;
    width: 400px;
    background-color: rgba(255,255,255,0.13);
    position: absolute;
    transform: translate(-50%,-50%);
    top: 55%;
    left: 50%;
    border-radius: 10px;
    backdrop-filter: blur(10px);
    border: 2px solid rgba(255,255,255,0.1);
    box-shadow: 0 0 40px rgba(8,7,16,0.6);
    padding: 50px 35px;
}
</style>
</head>
	<div style="border: 2px solid rgba(255,255,255,2); padding: 10px; width: auto; border-radius: 10px; background-color: rgba(255,255,255);">
	<?php
	echo "<p style='color:red;'> No session exists or session is expired. Please log in again.</p>";
	?>
	</div>
	<br>
	<?php
	echo "<button onclick=\"window.location.href = 'login.html'\">LOGIN</button>";
}
?>